# Et tu, Brute?
# Program written in Python3
# Seth Martin
# CSC 444
# 3/17/20
# This program takes in cypertext from stdin and generates candidate cyphers
# It then prints out the most likely candidate with the shift

import fileinput
import collections

# the alphabet
ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789`~!@#$%^&*()-_=+[{]}\|;:'\",<.>/? "

# Alternate alphabet for third cipher
#ALPHABET = " -,;:!?/.'\"()[]$&#%012345789aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxyYzZ"

# get words from the dictioanry
file = open("dictionary.txt", "r")
dictionary = file.readlines()
file.close()

# decrypt cipher function
def decrypt(cipher_text, shift):
    
    plain_text = []
    # Iterate through each character in the text
    for character in cipher_text:
        x = ALPHABET.index(character)
        # get index of character in ciphered alphabet
        x = (x - shift) % len(ALPHABET)
        # use new index in the original alphabet to get the decrypted character
        character = ALPHABET[x]
        plain_text.append(character)

    plain_text = "".join(plain_text)
    return plain_text

# see if word is in the dictionary
def checkDictionary(text):

    for word in dictionary:        
        # if the passed in word is a word in the dictionary return true, else return false
        if text == word.strip("\n"):
            return True
    return False


cipher_text = []

# Read  cipher text from stdin
for line in fileinput.input():
    line = line.rstrip("\n")
    cipher_text.append(line)

# make a string to get letter frequencies from
cipher_string = "\n".join(cipher_text)

# Get letter frequencies and prioritize shifts based off the most frequent letters
# generates a list of tuples with the letter and the number of times it occurs in order of most frequent to least
frequencies = collections.Counter(cipher_string).most_common()

# Generate candidates using the indicies of the most frequent letters as keys
candidates = []
for frequency in frequencies:

    # if character is not a new line
    if frequency[0] is not "\n":
        letter = frequency[0]

    key = ALPHABET.index(letter)

    plain_text= []
    
    # decrypt the text line by line
    for line in cipher_text:
        plain_line = decrypt(line, key)
        plain_text.append(plain_line)

    # create plain string
    plain_text = "\n".join(plain_text)

    # add string to candidates
    candidates.append((plain_text, key))

# Compare words in candidates to words in dictionary
for candidate in candidates:

    # Get text from candidate and split it by spaces into words
    text = candidate[0]
    text_list = text.split(" ")

    # count the number of words in the text that match words in the dictionary
    count = 0
    for word in text_list:
        if checkDictionary(word.strip(",!.?\"\n")) is True:
            count += 1
    
    # If more than 75% of the words match words in the dictionary use it as the plain text
    match_percentage = count/len(text_list)*100
    if match_percentage >= 75:
        print("SHIFT={}:".format(candidate[1]))
        print(candidate[0])

