You should have several documents:
(0) README.txt: This document...
(1) view-me.png: Clearly, an encrypted image.  Perhaps you need a key!
(2) view-me.enc: Ah, yes, perhaps this is the key.  It, too, appears to be encrypted.  You could try brute force, but that would likely take too long.  Perhaps you could use some assistance.
(3) assistance.b64: Some assistance!  Perhaps you can brute force this one more quickly.  It may be encoded using a method that allows binary data to be represented using only printable characters.
(4) dictionary.txt: A dictionary that may prove useful.

